package _21010310008_SecgulTurker;


	

	import java.io.BufferedReader;
	import java.io.File;
	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.List;
	import java.util.Scanner;
	import java.util.regex.Matcher;
	import java.util.regex.Pattern;
public class _21010310008_otomata {


		public static void main(String[] args) throws IOException {
			File txt = new File("fst.txt");
			BufferedReader reader = null;
			BufferedReader bufferedReader = reader = new BufferedReader(new FileReader(txt));

			String ilksatir = reader.readLine();

			ilksatir = ilksatir.replace("{", "");
			ilksatir = ilksatir.replace("}", "");
			ilksatir = ilksatir.replace("=", "");
			ilksatir = ilksatir.replace("Q", "");
			ilksatir = ilksatir.replace(" ", "");

		
			String[] gamma1 = new String[0]; 

			if (ilksatir != null) {
				gamma1 = ilksatir.split("\\s*,\\s*"); 

			
			String ikincisatir = reader.readLine();
			int c1 = ikincisatir.indexOf("{");
			int d = ikincisatir.indexOf("}");
			String degisken2 = ikincisatir.substring(c1, d);

			ikincisatir = ikincisatir.replace("{", "");
			ikincisatir = ikincisatir.replace("}", "");
			ikincisatir = ikincisatir.replace("=", "");
			ikincisatir = ikincisatir.replace("Σ", "");
			ikincisatir = ikincisatir.replace(" ", "");
			String[] sigma = new String[0];

			if (ikincisatir != null) {
				sigma = ikincisatir.split("\\s*,\\s*"); 
			}

			
			String ucuncusatir = reader.readLine();
			ucuncusatir = ucuncusatir.replace("{", "");
			ucuncusatir = ucuncusatir.replace("}", "");
			ucuncusatir = ucuncusatir.replace("=", "");
			ucuncusatir = ucuncusatir.replace("Γ", "");
			ucuncusatir = ucuncusatir.replace(" ", "");

			
			String[] gamma = new String[0];
			if (ucuncusatir != null) {
				gamma = ucuncusatir.split("\\s*,\\s*");
			}

			String state = "";

			String dosyaYolu = "fst.txt"; 
			String satir;
			int satirSayaci = 0;
			String s = "";

			while ((satir = bufferedReader.readLine()) != null) {
				satirSayaci++;

				if (satirSayaci == 2 || satirSayaci == 3) {
					int c = satir.indexOf("(");
					int d1 = satir.indexOf(")");
					String str = satir.substring(c + 1, d1);

					s = s + str + ", ";

					if (satir.length() >= 10) {
						satir = satir.substring(d1 + 1);
						int g1 = satir.indexOf("(");
						int f2 = satir.indexOf(")");
						String str1 = satir.substring(g1 + 1, f2);

						satir = satir.substring(f2 + 1);
						s = s + str1 + ", ";

					}

					if (satir.length() >= 1) {

						int g1 = satir.indexOf("(");
						int f2 = satir.indexOf(")");
						String str4 = satir.substring(g1 + 1, f2);

						s = s + str4 + ",";

					}

				}
				if (satirSayaci == 4) {
					int v = satir.indexOf("=");
					satir = satir.substring(v + 1);
					state = satir;
				}
			}
			

			ArrayList<String> dizi = new ArrayList<>();
			String[] values = s.split(",");
			dizi.addAll(Arrays.asList(values));
			ArrayList<String> secgul;

			secgul = dizi;

			String[] bjk;
			String secgul1 = qlar(secgul);
			secgul1 = secgul1.replace(" ", "");
			int y = secgul1.indexOf("[");
			int z = secgul1.indexOf("]");
			secgul1 = secgul1.substring(y + 1, z);
			bjk = secgul1.split(",");

			bjk = secgul.toArray(bjk);

			String[] ist;
			String dizi61 = qlar(secgul);

			dizi61 = dizi61.replace(" ", "");
			int j = dizi61.indexOf("[");
			int c = dizi61.indexOf("]");
			dizi61 = dizi61.substring(j + 1, c);
			ist = dizi61.split(",");

			String[] dizi71 = new String[ist.length / 2];
			String[] dizi81 = new String[ist.length / 2];
			for (int i = 0; i < dizi71.length; i++) {
				dizi71[i] = ist[i];

			}
			
			for (int i = 0; i < dizi81.length; i++) {
				dizi81[i] = ist[i + 3];

			}
			

			
			s = "";
			String[] dizi4;
			String dizi3 = dizi(dizi);

			dizi3 = dizi3.replace(" ", "");
			int k = dizi3.indexOf("[");
			int l = dizi3.indexOf("]");
			dizi3 = dizi3.substring(k + 1, l);
			dizi4 = dizi3.split(",");

			String[] dizi5;
			String dizi6 = dizi(dizi);

			dizi6 = dizi6.replace(" ", "");
			int f = dizi6.indexOf("[");
			int g = dizi6.indexOf("]");
			dizi6 = dizi6.substring(f + 1, g);
			dizi5 = dizi6.split(",");

			String[] dizi7 = new String[dizi5.length / 2];
			String[] dizi8 = new String[dizi5.length / 2];
			for (int i = 0; i < dizi7.length; i++) {
				dizi7[i] = dizi5[i];

			}
			
			for (int i = 0; i < dizi8.length; i++) {
				dizi8[i] = dizi5[i + 3];

			}
			
			String[][] ikiboyut = new String[gamma1.length + 1][sigma.length + 1];

			ikiboyut[0][0] = "δ";
			ikiboyut[0][1] = sigma[0];
			ikiboyut[0][2] = sigma[1];
			ikiboyut[0][3] = sigma[2];
			ikiboyut[1][0] = gamma1[0];
			ikiboyut[1][1] = dizi71[0] + " " + dizi7[0];
			ikiboyut[1][2] = dizi71[1] + " " + dizi7[1];
			ikiboyut[1][3] = dizi71[2] + " " + dizi7[2];
			ikiboyut[2][0] = gamma1[1];
			ikiboyut[2][1] = dizi81[0] + " " + dizi8[0];
			ikiboyut[2][2] = dizi81[1] + " " + dizi8[1];
			ikiboyut[2][3] = dizi81[2] + " " + dizi8[2];

			for (int i = 0; i < ikiboyut.length; i++) {
				for (int u = 0; u < ikiboyut[i].length; u++) {
					
				}
				
			}

			Scanner scanner = new Scanner(System.in);
			System.out.println("Lütfen birinci inputu girin: ");
			String girdi = scanner.nextLine();
			
			String sonuc1 = state;
			String sonuc11="";
			 
			boolean durum=true;
			_21010310008_otomata1 otomata=new _21010310008_otomata1();
			otomata.otomata1(girdi,sonuc1,sonuc11,sigma,gamma1,dizi71,dizi7,dizi81,dizi8,state,durum);
			

		}

		}
		
		private static String qlar(ArrayList<String> secgul) {

			String[] dizi2 = new String[secgul.size() / 2];

			int c = 0;
			for (int a = 0; a < secgul.size(); a++) {
				if (a % 2 == 0) {
					if (c < dizi2.length) {
						dizi2[c] = secgul.get(a);
						c++;

					}

				}

			}
			return Arrays.toString(dizi2);

		}

		private static String dizi(ArrayList<String> dizi) {
			String[] dizi1 = new String[dizi.size() / 2];

			int b = 0;

			for (int a = 0; a < dizi.size(); a++) {
				if (a % 2 == 1) {
					if (b < dizi1.length) {
						dizi1[b] = dizi.get(a);
						b++;

					}

				}

			}
			return Arrays.toString(dizi1);

		}
	}

