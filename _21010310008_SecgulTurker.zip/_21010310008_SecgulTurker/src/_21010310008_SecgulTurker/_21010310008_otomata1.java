package _21010310008_SecgulTurker;

import java.util.Scanner;

public class _21010310008_otomata1 {
	static void otomata1(String girdi, String sonuc1, String sonuc11, String[] sigma, String[] gamma1,
			String[] dizi71, String[] dizi7, String[] dizi81, String[] dizi8, String state, boolean durum) {
		for (int i = 0; i < girdi.length(); i++) {
			if (Character.toString(girdi.charAt(i)).contains(sigma[0])
					|| Character.toString(girdi.charAt(i)).contains(sigma[1])
					|| Character.toString(girdi.charAt(i)).contains(sigma[2])) {

				
			}

			else {
				System.out.println(
						"hatal� girdiniz" + sigma[0] + " " + sigma[1] + " " + sigma[2] + "+ bunlardan birini gir");
				durum=false;
			}}
		if(durum) {
			for (int m = 0; m < girdi.length(); m++) {
				for (int n = 0; n < sigma.length; n++) {
					if (sigma[n].contains(Character.toString(girdi.charAt(m)))) {
						if(state.contains(gamma1[0])) {
							sonuc1 +=","+ dizi71[n];
							sonuc11+=dizi7[n];
							state=dizi71[n];
							
						}
						else if(state.contains(gamma1[1])){
							sonuc1+=","+dizi81[n];
							sonuc11+=dizi8[n];
							state=dizi81[n];
							
						}
						
					}
				
				}
			}System.out.println("Durumlar�n s�ras�:" +sonuc1);
			System.out.println("��kt�: "+sonuc11);
		}Scanner scanner1 = new Scanner(System.in);
		System.out.println("L�tfen ikinci inputu girin: ");
		String girdi2 = scanner1.nextLine();
	
		String sonuc2 = state;
		String sonuc21="";
		boolean durum22=true;
		for (int i = 0; i < girdi2.length(); i++) {
			if (Character.toString(girdi2.charAt(i)).contains(sigma[0])
					|| Character.toString(girdi2.charAt(i)).contains(sigma[1])
					|| Character.toString(girdi2.charAt(i)).contains(sigma[2])) {

				
			}

			else {
				System.out.println(
						"hatal� girdiniz" + sigma[0] + " " + sigma[1] + " " + sigma[2] + "+ bunlardan birini gir");
				durum22=false;
			}}
		if(durum22) {
			for (int m = 0; m < girdi2.length(); m++) {
				for (int n = 0; n < sigma.length; n++) {
					if (sigma[n].contains(Character.toString(girdi2.charAt(m)))) {
						if(state.contains(gamma1[0])) {
							sonuc2 +=","+ dizi71[n];
							sonuc21+=dizi7[n];
							state=dizi71[n];
							
						}
						else if(state.contains(gamma1[1])){
							sonuc2+=","+dizi81[n];
							sonuc21+=dizi8[n];
							state=dizi81[n];
							
						}
						
					}
				
				}
			}System.out.println("Durumlar�n s�ras�:" +sonuc2);
			System.out.println("��kt�: "+sonuc21);
		}
		}

		
	}

